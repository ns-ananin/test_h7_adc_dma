var searchData=
[
  ['sizebuffer_0',['sizeBuffer',['../main_8c.html#aa436420b9fdbd39a56e38e9f8f570d00',1,'main.c']]]
];
