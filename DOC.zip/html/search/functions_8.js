var searchData=
[
  ['testtask_5fexecute_0',['TestTask_execute',['../group__test__task.html#ga0637d7c5ad928622a1f2ec651ea51af8',1,'TestTask_execute():&#160;TestTask.c'],['../group__test__task.html#ga0637d7c5ad928622a1f2ec651ea51af8',1,'TestTask_execute():&#160;TestTask.c']]],
  ['testtask_5fgetvoltage_1',['TestTask_getVoltage',['../group__test__task.html#ga5fa998bc759a8ad5023b946a0633fa09',1,'TestTask_getVoltage():&#160;TestTask.c'],['../group__test__task.html#ga5fa998bc759a8ad5023b946a0633fa09',1,'TestTask_getVoltage():&#160;TestTask.c']]],
  ['testtask_5finit_2',['TestTask_init',['../group__test__task.html#ga864974620430fc1be3427bccfa413361',1,'TestTask_init():&#160;TestTask.c'],['../group__test__task.html#ga864974620430fc1be3427bccfa413361',1,'TestTask_init():&#160;TestTask.c']]],
  ['testtask_5fisreadyvoltage_3',['TestTask_isReadyVoltage',['../group__test__task.html#ga6458db60cf5f0a8ef0438b4b817962fa',1,'TestTask.h']]],
  ['testtask_5fprocessadcvalues_4',['TestTask_processADCvalues',['../group__test__task.html#ga0988275b854438230ada87ec4e8c3076',1,'TestTask_processADCvalues(uint16_t *data, size_t sizeData):&#160;TestTask.c'],['../group__test__task.html#ga0988275b854438230ada87ec4e8c3076',1,'TestTask_processADCvalues(uint16_t *data, size_t sizeData):&#160;TestTask.c']]]
];
