var searchData=
[
  ['use_5fsd_5ftransceiver_0',['USE_SD_TRANSCEIVER',['../stm32h7xx__hal__conf_8h.html#a1f536ac7d8e274d77d384455b0bb994f',1,'stm32h7xx_hal_conf.h']]],
  ['use_5fspi_5fcrc_1',['USE_SPI_CRC',['../stm32h7xx__hal__conf_8h.html#a4c6fab687afc7ba4469b1b2d34472358',1,'stm32h7xx_hal_conf.h']]]
];
