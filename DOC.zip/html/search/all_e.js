var searchData=
[
  ['тестовое_20задание_0',['Тестовое задание',['../group__test__task.html',1,'']]]
];
